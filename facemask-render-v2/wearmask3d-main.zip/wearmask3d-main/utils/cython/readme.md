### Cython compiling
```
python3 setup.py build_ext -i
```

The `mesh_core_cython.*.so` will be generated. The specific name depends on your system.